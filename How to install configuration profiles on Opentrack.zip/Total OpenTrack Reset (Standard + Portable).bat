@echo off
title Total OpenTrack Reset (Standard + Portable)
echo ===================================================
echo TOTAL OPENTRACK RESET (Standard and Portable)
echo ===================================================
echo.

:: 1. Force close OpenTrack if running
echo [1/4] Closing running OpenTrack processes...
taskkill /f /im opentrack.exe >nul 2>&1

:: 2. Standard Version Reset (AppData)
echo [2/4] Deleting profiles and cache from Standard version (AppData)...
if exist "%appdata%\opentrack" (
rd /s /q "%appdata%\opentrack" >nul 2>&1
echo - AppData\opentrack folder removed.
) else (
echo - No standard installation found in AppData.
)

:: 3. Portable Version Reset (Local Folder)
echo [3/4] Deleting profiles and cache from local Portable version...
if exist "%~dp0settings" (
rd /s /q "%~dp0settings" >nul 2>&1
echo - Portable version settings subfolder removed.
)
del /f /q "%~dp0*.ini" >nul 2>&1
echo - .ini files in the current folder removed.

:: 4. Windows Registry Cleanup (if present)
echo [4/4] Cleaning up Windows registry keys...
reg delete "HKEY_CURRENT_USER\Software\opentrack" /f >nul 2>&1
reg delete "HKEY_CURRENT_USER\SOFTWARE\NaturalPoint" /f >nul 2>&1
echo - Registry cleaned up.

echo.
echo ===================================================
echo Reset successfully completed for both versions!
echo ===================================================
pause
